def f(x):
    return x + 4

x = f(1)
y = f(0)
z = f(-1)
print x * y * z
