a = 4
b = 3
print a * b

c = 7
d = 2
print c * d

e = "5"
f = "3"
print e + f
